var choices = [
  {
    name: 'Indian Tandoor',
    value: 'https://www.doordash.com/store/indian-tandoor-san-diego-29493/'
  },
  {
    name: 'Wich Addiction',
    value: 'https://www.doordash.com/store/wich-addiction-san-diego-46361/66434/'
  },
  {
    name: 'Urban Plates',
    value: 'https://www.doordash.com/store/urban-plates-san-diego-64651/'
  },
  {
    name: 'Star Anise',
    value: 'https://www.doordash.com/store/star-anise-san-diego-29407/'
  },
  {
    name: 'Micheline\'s Pita House',
    value: 'https://www.doordash.com/store/micheline-s-pita-house-san-diego-63504/'
  },
  {
    name: 'The Greek Cafe',
    value: 'https://www.doordash.com/store/the-greek-cafe-san-diego-63361/'
  },
  {
    name: 'Urbane Cafe',
    value: 'https://www.doordash.com/store/urbane-cafe-san-diego-63394/'
  },
  {
    name: 'Bibigo Fresh Korean',
    value: 'https://www.doordash.com/store/bibigo-fresh-korean-kitchen-san-diego-88465/'
  },
  {
    name: 'Corner Bakery Cafe',
    value: 'https://www.doordash.com/store/corner-bakery-cafe-san-diego-73510/110502/'
  },
  {
    name: 'Crust Pizzeria',
    value: 'https://www.doordash.com/store/crust-pizzeria-san-diego-63806/'
  },
  {
    name: 'Cafe Jay',
    value: 'https://www.doordash.com/store/cafe-jay-san-diego-63470/',
  }
]

module.exports = choices